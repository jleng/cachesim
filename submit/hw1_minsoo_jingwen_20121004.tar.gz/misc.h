//#define _DEBUG_
#define _STAT_
//#define _SANITY_
#define	NUM_OF_CORES 4
#define L2_NUM_OF_BANKS	16

